package co.caringfriends.caringfriendsv10;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class CheckIn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Roboto-RobotoRegular.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build()
        );
        setContentView(R.layout.activity_check_in);
        //YOU NEED THESE TWO TAGS FOR THIS TO WORK, MUST APPLY THIS TO ALL CLASSES

        //UNPACK IS EMPTY, NO DATA RECEIVED FROM PREVIOUS ACTIVITY

        final Button checkInButton = (Button)findViewById(R.id.checkInButton);
        checkInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText nameOfOlderAdult = (EditText)findViewById(R.id.nameOfOlderAdult);
                EditText nameOfVisitingFriend = (EditText)findViewById(R.id.nameOfVisitingFriend);
                EditText dateOfVisit = (EditText)findViewById(R.id.dateOfVisit);
                EditText cityOfVisit = (EditText)findViewById(R.id.cityOfVisit);

                String nameOfOlderAdultString = nameOfOlderAdult.getText().toString();
                String nameOfVisitingFriendString = nameOfVisitingFriend.getText().toString();
                String dateOfVisitString = dateOfVisit.getText().toString();
                String cityOfVisitString = cityOfVisit.getText().toString();

                Intent intent = new Intent(CheckIn.this, PersonalInfo.class);

                if (
                        checkEmpty(nameOfOlderAdult) == false &&
                                checkEmpty(nameOfVisitingFriend) == false &&
                                checkEmpty(dateOfVisit) == false &&
                                checkEmpty(cityOfVisit) == false
                        )
                {
                    //PACK UP
                    intent.putExtra("NAME_ADULT", nameOfOlderAdultString);
                    intent.putExtra("NAME_FRIEND", nameOfVisitingFriendString);
                    intent.putExtra("DATE_VISIT", dateOfVisitString);
                    intent.putExtra("CITY_VISIT", cityOfVisitString);
                    startActivity(intent);
                }

                else
                {
                    Toast.makeText(CheckIn.this, "Oops! Looks like you missed a field.", Toast.LENGTH_LONG).show();


                }

            }
        });

    }

    public boolean checkEmpty (EditText Text){

        return Text.getText().toString().trim().length() == 0;
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
    //THIS MUST BE ADDED TO ALL CLASSES
}
