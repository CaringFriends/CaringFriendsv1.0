package co.caringfriends.caringfriendsv10;

import android.content.Intent;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class Observations extends AppCompatActivity {

int delay = 50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_observations);

        //ESTABLISH RETROFIT DATA CONNECTION
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://docs.google.com/forms/d/")
                .build();
        final WebConnect spreadsheetWebService = retrofit.create(WebConnect.class);

        findViewById(R.id.observationsButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //UNPACK FROM PREVIOUS ACTIVITY
                final String question1Full = getIntent().getExtras().getString("QUESTION1_KEY");
                final String question2Full = getIntent().getExtras().getString("QUESTION2_KEY");
                final String question3Full = getIntent().getExtras().getString("QUESTION3_KEY");
                final String question4Full = getIntent().getExtras().getString("QUESTION4_KEY");
                final String question5Full = getIntent().getExtras().getString("QUESTION5_KEY");
                final String question6Full = getIntent().getExtras().getString("QUESTION6_KEY");
                final String question7Full = getIntent().getExtras().getString("QUESTION7_KEY");
                final String question8Full = getIntent().getExtras().getString("QUESTION8_KEY");
                final String question9Full = getIntent().getExtras().getString("QUESTION9_KEY");
                final String question10Full = getIntent().getExtras().getString("QUESTION10_KEY");
                final String question11Full = getIntent().getExtras().getString("QUESTION11_KEY");
                final String question12Full = getIntent().getExtras().getString("QUESTION12_KEY");
                final String question13Full = getIntent().getExtras().getString("QUESTION13_KEY");
                final String question14Full = getIntent().getExtras().getString("QUESTION14_KEY");
                final String question15Full = getIntent().getExtras().getString("QUESTION15_KEY");
                final String question16Full = getIntent().getExtras().getString("QUESTION16_KEY");
                final String question17Full = getIntent().getExtras().getString("QUESTION17_KEY");
                final String question18Full = getIntent().getExtras().getString("QUESTION18_KEY");
                final String question19Full = getIntent().getExtras().getString("QUESTION19_KEY");
                final String question20Full = getIntent().getExtras().getString("QUESTION20_KEY");
                final String question21Full = getIntent().getExtras().getString("QUESTION21_KEY");
                final String question22Full = getIntent().getExtras().getString("QUESTION22_KEY");
                final String question23Full = getIntent().getExtras().getString("QUESTION23_KEY");
                final String question24Full = getIntent().getExtras().getString("QUESTION24_KEY");
                final String question25Full = getIntent().getExtras().getString("QUESTION25_KEY");

                final String question1Part2Full = getIntent().getExtras().getString("QUESTION1_PART2_KEY");
                final String question3Part2Full = getIntent().getExtras().getString("QUESTION3_PART2_KEY");
                final String question13Part2Full = getIntent().getExtras().getString("QUESTION13_PART2_KEY");
                final String question20Part2Full = getIntent().getExtras().getString("QUESTION20_PART2_KEY");
                final String question24Part2Full = getIntent().getExtras().getString("QUESTION24_PART2_KEY");

                final String nameOfOlderAdult = getIntent().getExtras().getString("NAME_ADULT");
                final String nameOfVisitingFriend = getIntent().getExtras().getString("NAME_FRIEND");
                final String dateOfVisit = getIntent().getExtras().getString("DATE_VISIT");
                final String cityOfVisit = getIntent().getExtras().getString("CITY_VISIT");

                //FIND ALL OF THE RADIO GROUPS
                RadioGroup observation1Group = (RadioGroup) findViewById(R.id.observation1);
                RadioGroup observation2Group = (RadioGroup) findViewById(R.id.observation2);
                RadioGroup observation3Group = (RadioGroup) findViewById(R.id.observation3);
                RadioGroup observation4Group = (RadioGroup) findViewById(R.id.observation4);
                RadioGroup observation5Group = (RadioGroup) findViewById(R.id.observation5);
                RadioGroup observation6Group = (RadioGroup) findViewById(R.id.observation6);
                RadioGroup observation7Group = (RadioGroup) findViewById(R.id.observation7);
                RadioGroup observation8Group = (RadioGroup) findViewById(R.id.observation8);
                RadioGroup observation9Group = (RadioGroup) findViewById(R.id.observation9);
                RadioGroup observation10Group = (RadioGroup) findViewById(R.id.observation10);
                RadioGroup observation11Group = (RadioGroup) findViewById(R.id.observation11);
                RadioGroup observation12Group = (RadioGroup) findViewById(R.id.observation12);
                RadioGroup observation13Group = (RadioGroup) findViewById(R.id.observation13);
                RadioGroup observation14Group = (RadioGroup) findViewById(R.id.observation14);

                //FIND THE CHECKED RADIO BUTTONS
                RadioButton observation1Checked = (RadioButton) findViewById(observation1Group.getCheckedRadioButtonId());
                RadioButton observation2Checked = (RadioButton) findViewById(observation2Group.getCheckedRadioButtonId());
                RadioButton observation3Checked = (RadioButton) findViewById(observation3Group.getCheckedRadioButtonId());
                RadioButton observation4Checked = (RadioButton) findViewById(observation4Group.getCheckedRadioButtonId());
                RadioButton observation5Checked = (RadioButton) findViewById(observation5Group.getCheckedRadioButtonId());
                RadioButton observation6Checked = (RadioButton) findViewById(observation6Group.getCheckedRadioButtonId());
                RadioButton observation7Checked = (RadioButton) findViewById(observation7Group.getCheckedRadioButtonId());
                RadioButton observation8Checked = (RadioButton) findViewById(observation8Group.getCheckedRadioButtonId());
                RadioButton observation9Checked = (RadioButton) findViewById(observation9Group.getCheckedRadioButtonId());
                RadioButton observation10Checked = (RadioButton) findViewById(observation10Group.getCheckedRadioButtonId());
                RadioButton observation11Checked = (RadioButton) findViewById(observation11Group.getCheckedRadioButtonId());
                RadioButton observation12Checked = (RadioButton) findViewById(observation12Group.getCheckedRadioButtonId());
                RadioButton observation13Checked = (RadioButton) findViewById(observation13Group.getCheckedRadioButtonId());
                RadioButton observation14Checked = (RadioButton) findViewById(observation14Group.getCheckedRadioButtonId());


                //CHECK FOR ANY NULL RADIOBUTTONS CREATED
                if (
                        observation1Checked != null &&
                        observation2Checked != null &&
                                observation3Checked != null &&
                                observation4Checked != null &&
                                observation5Checked != null &&
                                observation6Checked != null &&
                                observation7Checked != null &&
                                observation8Checked != null &&
                                observation9Checked != null &&
                                observation10Checked != null &&
                                observation11Checked != null &&
                                observation12Checked != null &&
                                observation13Checked != null &&
                                observation14Checked != null
                        )
                {
                    //GET THE STRINGS FROM THE RESPONSES
                    String observation1Response = observation1Checked.getText().toString();
                    String observation2Response = observation2Checked.getText().toString();
                    String observation3Response = observation3Checked.getText().toString();
                    String observation4Response = observation4Checked.getText().toString();
                    String observation5Response = observation5Checked.getText().toString();
                    String observation6Response = observation6Checked.getText().toString();
                    String observation7Response = observation7Checked.getText().toString();
                    String observation8Response = observation8Checked.getText().toString();
                    String observation9Response = observation9Checked.getText().toString();
                    String observation10Response = observation10Checked.getText().toString();
                    String observation11Response = observation11Checked.getText().toString();
                    String observation12Response = observation12Checked.getText().toString();
                    String observation13Response = observation13Checked.getText().toString();
                    String observation14Response = observation14Checked.getText().toString();

                    //FIND THE TEXTVIEWS
                    TextView observation1TextView = (TextView) findViewById(R.id.observation1Text);
                    TextView observation2TextView = (TextView) findViewById(R.id.observation2Text);
                    TextView observation3TextView = (TextView) findViewById(R.id.observation3Text);
                    TextView observation4TextView = (TextView) findViewById(R.id.observation4Text);
                    TextView observation5TextView = (TextView) findViewById(R.id.observation5Text);
                    TextView observation6TextView = (TextView) findViewById(R.id.observation6Text);
                    TextView observation7TextView = (TextView) findViewById(R.id.observation7Text);
                    TextView observation8TextView = (TextView) findViewById(R.id.observation8Text);
                    TextView observation9TextView = (TextView) findViewById(R.id.observation9Text);
                    TextView observation10TextView = (TextView) findViewById(R.id.observation10Text);
                    TextView observation11TextView = (TextView) findViewById(R.id.observation11Text);
                    TextView observation12TextView = (TextView) findViewById(R.id.observation12Text);
                    TextView observation13TextView = (TextView) findViewById(R.id.observation13Text);
                    TextView observation14TextView = (TextView) findViewById(R.id.observation14Text);

                    //GET STRINGS FROM THE TEXTVIEWS
                    String observation1Text = observation1TextView.getText().toString();
                    String observation2Text = observation2TextView.getText().toString();
                    String observation3Text = observation3TextView.getText().toString();
                    String observation4Text = observation4TextView.getText().toString();
                    String observation5Text = observation5TextView.getText().toString();
                    String observation6Text = observation6TextView.getText().toString();
                    String observation7Text = observation7TextView.getText().toString();
                    String observation8Text = observation8TextView.getText().toString();
                    String observation9Text = observation9TextView.getText().toString();
                    String observation10Text = observation10TextView.getText().toString();
                    String observation11Text = observation11TextView.getText().toString();
                    String observation12Text = observation12TextView.getText().toString();
                    String observation13Text = observation13TextView.getText().toString();
                    String observation14Text = observation14TextView.getText().toString();

                    //CONCATENATE THOSE STRINGS
                    final String observation1Full = observation1Text + "\n" + observation1Response;
                    final String observation2Full = observation2Text + "\n" + observation2Response;
                    final String observation3Full = observation3Text + "\n" + observation3Response;
                    final String observation4Full = observation4Text + "\n" + observation4Response;
                    final String observation5Full = observation5Text + "\n" + observation5Response;
                    final String observation6Full = observation6Text + "\n" + observation6Response;
                    final String observation7Full = observation7Text + "\n" + observation7Response;
                    final String observation8Full = observation8Text + "\n" + observation8Response;
                    final String observation9Full = observation9Text + "\n" + observation9Response;
                    final String observation10Full = observation10Text + "\n" + observation10Response;
                    final String observation11Full = observation11Text + "\n" + observation11Response;
                    final String observation12Full = observation12Text + "\n" + observation12Response;
                    final String observation13Full = observation13Text + "\n" + observation13Response;
                    final String observation14Full = observation14Text + "\n" + observation14Response;

                    Intent intent = new Intent(Observations.this, Notes.class);

                    Call<Void> completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(nameOfOlderAdult);
                    completeQuestionnaireCall.enqueue(callCallback);

                    //CREATE DELAYS IN CODE TO STAGGER-STEP THE SENDING OF DATA SO THAT EVERYTHING
                    //ARRIVES IN ORDER ON SERVER SIDE, 10 MILLISECOND STEP

                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(nameOfVisitingFriend);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(dateOfVisit);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(cityOfVisit);
                    completeQuestionnaireCall.enqueue(callCallback);

                    //4

                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question1Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question1Part2Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question2Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question3Full);
                    completeQuestionnaireCall.enqueue(callCallback);


                    //8
                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question3Part2Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question4Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question5Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question6Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    //12


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question7Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question8Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(nameOfOlderAdult);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question9Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    //16


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question10Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question11Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question12Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question13Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    //20

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question13Part2Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question14Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question15Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question16Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    //24

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question17Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question18Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question19Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question20Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);
                    //28

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question20Part2Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question21Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question22Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question23Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    //32

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question24Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question24Part2Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(question25Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation1Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    //36

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation2Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation3Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation4Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation5Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    //40

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation6Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation7Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation8Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation9Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation10Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);

                    //44

                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation11Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation12Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation13Full);
                    completeQuestionnaireCall.enqueue(callCallback);

                    SystemClock.sleep(delay);


                    completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(observation14Full);
                    completeQuestionnaireCall.enqueue(callCallback);


                    //49 END
                    //QUARANTINE ALL V-LOGGED VALUES IMMEDIATELY
                    //ALL V-LOGGED VALUES KEEP TRIPPING OVER SAME STRING

//                Log.v("OBSERVATIONS", question1Full);
//                Log.v("OBSERVATIONS", question2Full);
//                Log.v("OBSERVATIONS", question3Full);
//                Log.v("OBSERVATIONS", question4Full);
//                Log.v("OBSERVATIONS", question5Full);
//                Log.v("OBSERVATIONS", question6Full);
//                Log.v("OBSERVATIONS", question7Full);
//                Log.v("OBSERVATIONS", question8Full);
//                Log.v("OBSERVATIONS", question9Full);
//                Log.v("OBSERVATIONS", question10Full);
//                Log.v("OBSERVATIONS", question11Full);
//                Log.v("OBSERVATIONS", question12Full);
//                Log.v("OBSERVATIONS", question13Full);
//                Log.v("OBSERVATIONS", question14Full);
//                Log.v("OBSERVATIONS", question15Full);
//                Log.v("OBSERVATIONS", question16Full);
//                Log.v("OBSERVATIONS", question17Full);
//                Log.v("OBSERVATIONS", question18Full);
//                Log.v("OBSERVATIONS", question19Full);
//                Log.v("OBSERVATIONS", question20Full);
//                Log.v("OBSERVATIONS", question21Full);
//                Log.v("OBSERVATIONS", question22Full);
//                Log.v("OBSERVATIONS", question23Full);
//                Log.v("OBSERVATIONS", question24Full);
//                Log.v("OBSERVATIONS", question25Full);
//
//                Log.d("OBSERVATIONS", question1Part2Full);
//                Log.d("OBSERVATIONS", question3Part2Full);
//                Log.d("OBSERVATIONS", question13Part2Full);
//                Log.d("OBSERVATIONS", question20Part2Full);
//
//                Log.d("OBSERVATIONS", observation1Full);
//                Log.d("OBSERVATIONS", observation2Full);
//                Log.d("OBSERVATIONS", observation3Full);
//                Log.d("OBSERVATIONS", observation4Full);
//                Log.d("OBSERVATIONS", observation5Full);
//                Log.d("OBSERVATIONS", observation6Full);
//                Log.d("OBSERVATIONS", observation7Full);
//                Log.d("OBSERVATIONS", observation8Full);
//                Log.d("OBSERVATIONS", observation9Full);
//                Log.d("OBSERVATIONS", observation10Full);
//                Log.d("OBSERVATIONS", observation11Full);
//                Log.d("OBSERVATIONS", observation12Full);
//                Log.d("OBSERVATIONS", observation13Full);
//                Log.d("OBSERVATIONS", observation14Full);

                    //NEW INTENTS
                    //*EDIT DO NOT NEED THIS INTENT BECAUSE THE DATA IS TRANSMITTED AT THE END OF THE SUBMIT METHOD

//                intent.putExtra("OBSERVATION1_KEY", observation1Full);
//                intent.putExtra("OBSERVATION2_KEY", observation2Full);
//                intent.putExtra("OBSERVATION3_KEY", observation3Full);
//                intent.putExtra("OBSERVATION4_KEY", observation4Full);
//                intent.putExtra("OBSERVATION5_KEY", observation5Full);
//                intent.putExtra("OBSERVATION6_KEY", observation6Full);
//                intent.putExtra("OBSERVATION7_KEY", observation7Full);
//                intent.putExtra("OBSERVATION8_KEY", observation8Full);
//                intent.putExtra("OBSERVATION9_KEY", observation9Full);
//                intent.putExtra("OBSERVATION10_KEY", observation10Full);
//                intent.putExtra("OBSERVATION11_KEY", observation11Full);
//                intent.putExtra("OBSERVATION12_KEY", observation12Full);
//                intent.putExtra("OBSERVATION13_KEY", observation13Full);
//                intent.putExtra("OBSERVATION14_KEY", observation14Full);

                    //PACK UP THE INTENT
                    //*EDIT DO NOT NEED THIS INTENT BECAUSE THE DATA IS TRANSMITTED AT THE END OF THE SUBMIT METHOD

//                intent.putExtra("QUESTION1_KEY", question1Full);
//                intent.putExtra("QUESTION2_KEY", question2Full);
//                intent.putExtra("QUESTION3_KEY", question3Full);
//                intent.putExtra("QUESTION4_KEY", question4Full);
//                intent.putExtra("QUESTION5_KEY", question5Full);
//                intent.putExtra("QUESTION6_KEY", question6Full);
//                intent.putExtra("QUESTION7_KEY", question7Full);
//                intent.putExtra("QUESTION8_KEY", question8Full);
//                intent.putExtra("QUESTION9_KEY", question9Full);
//                intent.putExtra("QUESTION10_KEY", question10Full);
//                intent.putExtra("QUESTION11_KEY", question11Full);
//                intent.putExtra("QUESTION12_KEY", question12Full);
//                intent.putExtra("QUESTION13_KEY", question13Full);
//                intent.putExtra("QUESTION14_KEY", question14Full);
//                intent.putExtra("QUESTION15_KEY", question15Full);
//                intent.putExtra("QUESTION16_KEY", question16Full);
//                intent.putExtra("QUESTION17_KEY", question17Full);
//                intent.putExtra("QUESTION18_KEY", question18Full);
//                intent.putExtra("QUESTION19_KEY", question19Full);
//                intent.putExtra("QUESTION20_KEY", question20Full);
//                intent.putExtra("QUESTION21_KEY", question21Full);
//                intent.putExtra("QUESTION22_KEY", question22Full);
//                intent.putExtra("QUESTION23_KEY", question23Full);
//                intent.putExtra("QUESTION24_KEY", question24Full);
//                intent.putExtra("QUESTION25_KEY", question25Full);
//
//                intent.putExtra("QUESTION1_PART2_KEY", question1Part2Full);
//                intent.putExtra("QUESTION3_PART2_KEY", question3Part2Full);
//                intent.putExtra("QUESTION13_PART2_KEY", question13Part2Full);
//                intent.putExtra("QUESTION20_PART2_KEY", question20Part2Full);
//                intent.putExtra("QUESTION24_PART2_KEY", question24Part2Full);
//
//                intent.putExtra("NAME_ADULT", nameOfOlderAdult);
//                intent.putExtra("NAME_FRIEND", nameOfVisitingFriend);
//                intent.putExtra("DATE_VISIT", dateOfVisit);
//                intent.putExtra("CITY_VISIT", cityOfVisit);
//
                    startActivity(intent);
                }

            else{
                    Toast.makeText(Observations.this, "Oops! Looks like you missed a question.", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    private final Callback<Void> callCallback = new Callback<Void>() {
        @Override
        public void onResponse(Response<Void> response) {
            Log.d("XXX", "Submitted. " + response);
        }

        @Override
        public void onFailure(Throwable t) {
            Log.e("XXX", "Failed", t);
        }
    };
}

